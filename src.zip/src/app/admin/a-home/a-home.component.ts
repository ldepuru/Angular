import { Component, Input, OnInit } from '@angular/core';
@Component({
  selector: 'app-a-home',
  templateUrl: './a-home.component.html',
  styleUrls: ['./a-home.component.css']
})
export class AHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
