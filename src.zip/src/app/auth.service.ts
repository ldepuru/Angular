import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private router: Router) {}

  isAdmin: boolean = false;

  setToken(token: string): void {
    localStorage.setItem('token', token);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  isLoggedIn() {
    return this.getToken() !== null;
  }

  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['login']);
  }

  login({ email, password }: any): Observable<any> {
    if (email === 'user@gmail.com' && password === 'user') {
      this.setToken('abcdefghijklmnopqrstuvwxyz');
      this.isAdmin = false;
      return of({ name: 'User', email: 'user@gmail.com' });
    }
    if(email === 'admin@gmail.com' && password === 'admin'){
      this.setToken('nopqrstuvwxyzabcdefghijklm');
      this.isAdmin = true;
      return of({ name: 'Admin', email: 'admin@gmail.com' });
    }
    return throwError(new Error('Failed to login!!'));

  }
}
