import { Component, OnInit } from '@angular/core';
import  TutorsJson  from './assets/tutors.json';

import { AuthService } from '../auth.service';

interface TUTORS {
  id: number;
  name: string;
  email: string;
  phone: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  Tutors: TUTORS[] = TutorsJson;

  isAdmin: boolean = false;

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.isAdmin = this.authService.isAdmin;
  }

}
